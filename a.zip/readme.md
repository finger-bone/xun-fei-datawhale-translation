# Introduction to Machine Translation

A summer camp held by DataWhale, not finished yet.

My codes and notes are in the `code` and `note` folders respectively.

Chinese version is hosted on [ZhiHu](https://www.zhihu.com/column/c_1795958334534316032)
